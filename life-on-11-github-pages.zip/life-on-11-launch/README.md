# Life on 11

A static, mobile-friendly first release of the Life on 11 app.

## What's included
- Branded Home, Listen, Grow, Resources, Profile and Admin Desk prototype screens
- Transistor.fm RSS episode loading using the feed URL already configured in the app
- Browser-local challenge progress, saved episodes and prayer journal
- Installable PWA manifest and basic offline shell caching

## Publish with GitHub Pages
1. Create a new GitHub repository named `life-on-11` (keep it separate from Refiners-75).
2. Upload all files in this folder to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then Save.
6. Wait for GitHub Pages to publish and open the URL shown on the Pages screen.

## Current limitations
This first release has no cloud database, user accounts, secure admin login, or shared publishing workflow. Journal entries and progress are stored in the browser on the device. The RSS feed is fetched in the browser through rss2json, so feed loading depends on that third-party service and internet access. Admin Desk is a prototype screen, not a protected publishing console.
